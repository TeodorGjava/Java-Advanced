package Genn;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] input = sc.nextLine().split(" ");
        Tuple<String, String> tuple = new Tuple<>(input[0] + " " + input[1], input[2]);

        input = sc.nextLine().split(" ");
        String name = input[0];
        int beerLiters = Integer.parseInt(input[1]);
        Tuple<String, Integer> tupleWithMixedData = new Tuple<String, Integer>(name, beerLiters);
        System.out.println(tupleWithMixedData);

        input = sc.nextLine().split(" ");
        int integerNumber = Integer.parseInt(input[0]);
        double doubleNumber = Double.parseDouble(input[0]);
        Tuple<Integer, Double> doubleTuple = new Tuple<>(integerNumber, doubleNumber);
        System.out.println(doubleTuple);


    }
}
