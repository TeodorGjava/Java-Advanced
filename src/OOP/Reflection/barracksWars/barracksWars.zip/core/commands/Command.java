package barracksWars.core.commands;

import barracksWars.interfaces.Repository;
import barracksWars.interfaces.UnitFactory;

public abstract class Command implements barracksWars.interfaces.Executable {
    private final String[] data;
    private final barracksWars.interfaces.Repository repository;
    private final barracksWars.interfaces.UnitFactory factory;

    protected Command(String[] data, Repository repository, UnitFactory factory) {
        this.data = data;
        this.repository = repository;
        this.factory = factory;
    }

    protected String[] getData() {
        return this.data;
    }

    protected Repository getRepository() {
        return this.repository;
    }

    protected UnitFactory getFactory() {
        return this.factory;
    }


}
