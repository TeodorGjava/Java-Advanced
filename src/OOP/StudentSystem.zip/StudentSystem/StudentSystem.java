package OOP.StudentSystem;

import java.util.HashMap;
import java.util.Map;

public class StudentSystem {
    private Map<String, Student> studentsByName;

    public StudentSystem() {
        this.studentsByName = new HashMap<>();
    }

    public Map<String, Student> getStudentsByName() {
        return this.studentsByName;
    }

    public void ParseCommand(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//        String[] args = scanner.nextLine().split(" ");
        String command = args[0];
        String name = args[1];

        if (command.equals("Create")) {

            int age = Integer.parseInt(args[2]);
            double grade = Double.parseDouble(args[3]);

            if (!studentsByName.containsKey(name)) {
                Student student = new Student(name, age, grade);
                studentsByName.put(name, student);
            }

        } else if (command.equals("Show")) {
            Student student = studentsByName.get(name);
            if (studentsByName != null) {
                System.out.println(student.getInfo());
            }
        }else{
            throw new IllegalStateException("Unknown command "+ command);
        }
    }
}
