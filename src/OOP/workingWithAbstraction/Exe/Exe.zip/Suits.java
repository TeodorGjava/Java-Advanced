package OOP.workingWithAbstraction.Exe;

public enum Suits {
    CLUBS, DIAMONDS, HEARTS, SPADES

}
